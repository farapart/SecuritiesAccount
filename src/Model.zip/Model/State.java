package Model;

public class State {
}
